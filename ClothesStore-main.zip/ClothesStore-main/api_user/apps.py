from django.apps import AppConfig


class ApiUserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api_user'
